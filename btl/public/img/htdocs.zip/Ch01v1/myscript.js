$(document).ready(function(){
    $.ajax({
        type:'POST',
        url:'register-view-users.php',
        dataType: 'JSON',
        success:function(data){
                var html = '', comment;
                for(var i = 0; i < data.length; i++){
                    comment = data[i];
                    html += '<div id="' + comment.userID + '"><span>' + comment.firstName + '</span><span>' + comment.lastName + '</span></div>';
                }
                $('#ketQua').html(html);
        }
    })
})