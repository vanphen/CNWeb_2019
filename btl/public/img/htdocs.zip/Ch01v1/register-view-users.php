<?php 
try {
// This script retrieves all the records from the users table.
require('mysqli_connect.php'); // Connect to the database.
// Make the query:
// Nothing passed from user safe query									#1
$query = "SELECT * FROM users";	
$result = mysqli_query ($dbcon, $query); // Run the query.
if ($result) { // If it ran OK, display the records.
  $results = array();
  while($row = mysqli_fetch_assoc($result))
  {
      $userID = $row['userid'];
      $firstName = $row['first_name'];
      $lastName = $row['last_name'];
      $email = $row['email'];

      $results[] = array("userID" => $userID, "firstName" => $firstName, "lastName" => $lastName, "email" => $email);

  }

      echo json_encode($results);


} else { // If it did not run OK.
// Error message:
echo '<p class="error">The current users could not be retrieved. We apologize';
echo ' for any inconvenience.</p>';
// Debug message:
// echo '<p>' . mysqli_error($dbcon) . '<br><br>Query: ' . $q . '</p>';
exit;
} // End of if ($result) 
mysqli_close($dbcon); // Close the database connection.
}
catch(Exception $e) // We finally handle any problems here                
   {
     // print "An Exception occurred. Message: " . $e->getMessage();
     print "The system is busy please try later";
   }
   catch(Error $e)
   {
      //print "An Error occurred. Message: " . $e->getMessage();
      print "The system is busy please try again later.";
   }
?>